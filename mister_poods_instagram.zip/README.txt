MISTER POODS — VERSÃO PRO
Abra index.html para visualizar.
Estrutura: HTML + CSS + JavaScript, responsiva e pronta para hospedagem.
A página é institucional e não possui venda, checkout, preços ou pedidos de vape.
Antes da publicação, conecte o formulário a um serviço de formulários e substitua os textos/canais demonstrativos.
